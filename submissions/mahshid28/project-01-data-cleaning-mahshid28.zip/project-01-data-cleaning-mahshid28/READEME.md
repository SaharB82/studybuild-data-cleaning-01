# Project 01: Customer Data Cleaning

## Dataset Issues Identified

- Missing values in the **age** and **total_spending** columns.
- A full duplicate record.
- An outlier age value.
- Inconsistent date format.
- Incorrect gender values in several records.

---

## Data Cleaning Actions

- the full duplicate record is dropped.
- the missing value in the **age** column filled by the mean.
- the missing value in **total_spending** calculated as below:

  **purchase_count × avg_order_value**

- An outlier age value is replaced with the median.
- Convert date format to datetime.

---

## Libraries

- Pandas
- Matplotlib

---

## Final Dataset Improvements

- No duplicate records.
- No missing values.
- No outlier values.
- Datetime format for signup_date column.
